import { MenuGatewayPort } from "@/domain/menu/ports";
import { EventMenu, MenuCatalog } from "@/domain/menu/types";

const API_BASE = import.meta.env.VITE_API_URL?.replace(/\/$/, "") ?? "";

type ApiResponse<T> = T | { data: T };

// Hace una petición; si hay 419, intenta obtener cookie CSRF y reintenta una vez.
async function http<T>(input: RequestInfo, init?: RequestInit, _retry = false): Promise<T> {
  const res = await fetch(input, {
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json",
      "X-Requested-With": "XMLHttpRequest",
      ...(init?.headers ?? {}),
    },
    credentials: "include",
    ...init,
  });

  if (res.status === 419 && !_retry) {
    // Intento de preflight CSRF (Laravel Sanctum SPA)
    try {
      await fetch(`${API_BASE}/sanctum/csrf-cookie`, { credentials: "include" });
      return http<T>(input, init, true);
    } catch {
      // seguimos para lanzar el error normal
    }
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status} ${res.statusText} - ${text}`);
  }

  const json = (await res.json()) as ApiResponse<T>;
  if (json && typeof json === "object" && json !== null && "data" in json) {
    return (json as any).data as T;
  }
  return json as T;
}

export class MenuHttpGateway implements MenuGatewayPort {
  async getCatalog(): Promise<MenuCatalog> {
    const url = `${API_BASE}/api/v1/menu/catalog`;
    return await http<MenuCatalog>(url);
  }
  async getEventMenu(eventId: number): Promise<EventMenu> {
    const url = `${API_BASE}/api/v1/events/${eventId}/menu`;
    return await http<EventMenu>(url);
  }
  async upsertEventMenu(
    eventId: number,
    payload: { dish_ids: number[]; drink_ids: number[]; extras: { id: number; quantity: number }[] }
  ): Promise<EventMenu> {
    const url = `${API_BASE}/api/v1/events/${eventId}/menu`;
    return await http<EventMenu>(url, { method: "PUT", body: JSON.stringify(payload) });
  }
}
