
export type MenuId = number;

export type CatalogDish = {
  id: number;
  name: string;
  type?: string | null;
  description?: string | null;
  picture_url?: string | null;
  price?: number | null;        
};

export type CatalogDrink = {
  id: number;
  name: string;
  type?: string | null;
  description?: string | null;
  picture_url?: string | null;
  price?: number | null;         
};

export type CatalogExtra = {
  id: number;
  name: string;
  description?: string | null;
  price?: number | null;         
};

export type MenuCatalog = {
  dishes: CatalogDish[];
  drinks: CatalogDrink[];
  extras: CatalogExtra[];
};

export type MenuExtraSelection = { id: number; quantity: number; name?: string };

export type EventMenu = {
  id: MenuId;
  url: string | null;
  dish_ids: number[];
  drink_ids: number[];
  extras: MenuExtraSelection[];
};
