import React, { useEffect, useMemo, useState } from "react";
import { makeMenuUseCases } from "@/application/menu/usecases";
import { CatalogDish, CatalogDrink, CatalogExtra, EventMenu, MenuCatalog, MenuExtraSelection } from "@/domain/menu/types";
import OptionGrid from "./OptionGrid";
import SelectedSummary from "./SelectedSummary";
import PdfActions from "@/features/shared/PdfActions";
type Props = { eventId: number };

type SelectionState = {
  dishes: Set<number>;
  drinks: Set<number>;
  extras: Map<number, number>; // id -> quantity
};

const uc = makeMenuUseCases();

export default function MenuTab({ eventId }: Props) {
  const [catalog, setCatalog] = useState<MenuCatalog | null>(null);
  const [menu, setMenu] = useState<EventMenu | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const [selection, setSelection] = useState<SelectionState>({
    dishes: new Set(),
    drinks: new Set(),
    extras: new Map(),
  });

  // Carga inicial
  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const [cat, current] = await Promise.all([uc.loadCatalog(), uc.getEventMenu(eventId)]);
        if (!mounted) return;
        setCatalog(cat);
        setMenu(current);
        setSelection({
          dishes: new Set(current.dish_ids),
          drinks: new Set(current.drink_ids),
          extras: new Map(current.extras.map((e) => [e.id, e.quantity])),
        });
      } catch (e: any) {
        if (!mounted) return;
        setError(e?.message ?? "Error cargando menú");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [eventId]);

  const selectedExtras: MenuExtraSelection[] = useMemo(
    () => Array.from(selection.extras.entries()).map(([id, quantity]) => ({ id, quantity })),
    [selection.extras]
  );

  // Handlers selección
  const toggleDish = (id: number) =>
    setSelection((s) => {
      const next = new Set(s.dishes);
      next.has(id) ? next.delete(id) : next.add(id);
      return { ...s, dishes: next };
    });

  const toggleDrink = (id: number) =>
    setSelection((s) => {
      const next = new Set(s.drinks);
      next.has(id) ? next.delete(id) : next.add(id);
      return { ...s, drinks: next };
    });

  const incExtra = (id: number) =>
    setSelection((s) => {
      const next = new Map(s.extras);
      next.set(id, (next.get(id) ?? 0) + 1);
      return { ...s, extras: next };
    });

  const decExtra = (id: number) =>
    setSelection((s) => {
      const next = new Map(s.extras);
      const q = (next.get(id) ?? 0) - 1;
      if (q <= 0) next.delete(id);
      else next.set(id, q);
      return { ...s, extras: next };
    });

  const clearMsgLater = () => setTimeout(() => setMessage(null), 3000);

  const onSave = async () => {
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      const saved = await uc.saveEventMenu(eventId, {
        dishes: Array.from(selection.dishes.values()),
        drinks: Array.from(selection.drinks.values()),
        extras: selectedExtras,
      });
      setMenu(saved);
      setMessage("Menú guardado y PDF generado.");
      clearMsgLater();
    } catch (e: any) {
      setError(e?.message ?? "Error guardando menú");
    } finally {
      setSaving(false);
    }
  };

  const dishMap = useMemo(() => new Map((catalog?.dishes ?? []).map((d) => [d.id, d])), [catalog]);
  const drinkMap = useMemo(() => new Map((catalog?.drinks ?? []).map((d) => [d.id, d])), [catalog]);
  const extraMap = useMemo(() => new Map((catalog?.extras ?? []).map((e) => [e.id, e])), [catalog]);

  if (loading) return <div className="p-4 text-sm text-[color:var(--color-text-main)]">Cargando menú…</div>;
  if (error) return <div className="p-4 text-sm text-[color:var(--color-alert)]">Error: {error}</div>;
  if (!catalog || !menu) return <div className="p-4">Sin datos de catálogo o menú.</div>;

  return (
    <div className="flex flex-col gap-6 p-4">
      {message && <div className="rounded-md bg-[color:var(--color-alt-bg)] px-3 py-2 text-sm">{message}</div>}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Section title="Platos">
            <OptionGrid<CatalogDish>
              items={catalog.dishes}
              isSelected={(id) => selection.dishes.has(id)}
              onToggle={toggleDish}
            />
          </Section>

          <Section title="Bodega">
            <OptionGrid<CatalogDrink>
              items={catalog.drinks}
              isSelected={(id) => selection.drinks.has(id)}
              onToggle={toggleDrink}
            />
          </Section>

          <Section title="Extras">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {(catalog.extras ?? []).map((e) => {
                const q = selection.extras.get(e.id) ?? 0;
                return (
                  <div
                    key={e.id}
                    className="rounded-xl border border-[color:var(--color-beige)] bg-white p-3 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-medium">{e.name}</div>
                      {e.description && <div className="text-xs text-gray-500">{e.description}</div>}
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        className="px-2 py-1 rounded-lg border border-[color:var(--color-secondary)] text-[color:var(--color-secondary)] hover:bg-[color:var(--color-bg-main)]"
                        onClick={() => decExtra(e.id)}
                        aria-label={`Quitar ${e.name}`}
                        type="button"
                      >
                        −
                      </button>
                      <div className="w-8 text-center">{q}</div>
                      <button
                        className="px-2 py-1 rounded-lg bg-[color:var(--color-secondary)] text-white hover:bg-[color:var(--color-secondary-hover)]"
                        onClick={() => incExtra(e.id)}
                        aria-label={`Añadir ${e.name}`}
                        type="button"
                      >
                        +
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </Section>
        </div>

        <aside className="lg:col-span-1">
          <SelectedSummary
            dishes={Array.from(selection.dishes).map((id) => dishMap.get(id)).filter(Boolean) as CatalogDish[]}
            drinks={Array.from(selection.drinks).map((id) => drinkMap.get(id)).filter(Boolean) as CatalogDrink[]}
            extras={Array.from(selection.extras.entries()).map(([id, quantity]) => ({
              ...(extraMap.get(id) ?? { id, name: `Extra ${id}` }),
              id,
              quantity,
            }))}
            onRemoveDish={(id) => toggleDish(id)}
            onRemoveDrink={(id) => toggleDrink(id)}
            onDecExtra={(id) => decExtra(id)}
            onIncExtra={(id) => incExtra(id)}
          />

          <div className="mt-4 flex flex-col gap-2">
            <button
              onClick={onSave}
              disabled={saving}
              className="w-full rounded-xl bg-[color:var(--color-primary)] text-white py-2 hover:bg-[color:var(--color-primary-hover)] disabled:opacity-60"
            >
              {saving ? "Guardando…" : "Guardar y generar PDF"}
            </button>

            <div className="rounded-xl border border-[color:var(--color-beige)] bg-white p-3">
              <div className="text-sm font-medium mb-2">PDF del menú</div>
              {menu.url ? (
                <PdfActions url={menu.url} />
              ) : (
                <div className="text-xs text-gray-500">Aún no hay PDF generado.</div>
              )}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="text-base font-bold text-[color:var(--color-text-main)] mb-2 tracking-wide">{title}</h3>
      {children}
    </section>
  );
}
