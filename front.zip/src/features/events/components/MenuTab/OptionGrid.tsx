import React, { useMemo, useState } from "react";
import OptionCard from "./OptionCard";

type Base = { id: number; name: string; type?: string | null; description?: string | null; picture_url?: string | null; price?: number | null };
type Props<T extends Base> = {
  items?: T[];
  isSelected: (id: number) => boolean;
  onToggle: (id: number) => void;
};

export default function OptionGrid<T extends Base>({ items, isSelected, onToggle }: Props<T>) {
  const list = (items ?? []).slice();

  const [query, setQuery] = useState("");

  // 1) Filtrado por texto (sin filtro por categoría)
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return list;
    return list.filter((i) => i.name.toLowerCase().includes(q) || (i.description ?? "").toLowerCase().includes(q));
  }, [list, query]);

  // 2) Agrupado por categoría (type), orden alfabético, items ordenados por nombre
  const groups = useMemo(() => {
    const map = new Map<string, T[]>();
    filtered.forEach((i) => {
      const key = (i.type && i.type.trim()) || "Otros";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(i);
    });
    const sorted = Array.from(map.entries()).sort(([a], [b]) => a.localeCompare(b));
    return sorted.map(([key, arr]) => [key, arr.sort((a, b) => a.name.localeCompare(b.name))] as const);
  }, [filtered]);

  return (
    <div className="flex flex-col gap-3">
      <div className="flex gap-2">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar…"
          className="w-full sm:max-w-xs rounded-xl border border-[color:var(--color-beige)] bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[color:var(--color-accent)]"
        />
      </div>

      {groups.map(([title, items]) => (
        <div key={title}>
          <h4 className="mt-4 mb-2 px-1 text-sm font-semibold uppercase tracking-wide text-[color:var(--color-secondary)]">
            {title}
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
            {items.map((i) => (
              <OptionCard
                key={i.id}
                id={i.id}
                name={i.name}
                type={i.type ?? undefined}
                description={i.description ?? undefined}
                picture_url={i.picture_url ?? undefined}
                price={i.price ?? undefined}
                selected={isSelected(i.id)}
                onToggle={() => onToggle(i.id)}
              />
            ))}
          </div>
        </div>
      ))}

      {!groups.length && (
        <div className="text-sm text-gray-500">No hay elementos que coincidan con la búsqueda.</div>
      )}
    </div>
  );
}
