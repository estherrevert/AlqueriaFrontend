import React, { useMemo } from "react";
import { CatalogDish, CatalogDrink, CatalogExtra } from "@/domain/menu/types";

const nf = new Intl.NumberFormat("es-ES", { style: "currency", currency: "EUR" });

type Props = {
  dishes: (CatalogDish)[];
  drinks: (CatalogDrink)[];
  extras: (CatalogExtra & { quantity: number })[];
  onRemoveDish: (id: number) => void;
  onRemoveDrink: (id: number) => void;
  onDecExtra: (id: number) => void;
  onIncExtra: (id: number) => void;
};

export default function SelectedSummary({
  dishes,
  drinks,
  extras,
  onRemoveDish,
  onRemoveDrink,
  onDecExtra,
  onIncExtra,
}: Props) {
  const subtotalDishes = useMemo(() => dishes.reduce((s, d) => s + (d.price ?? 0), 0), [dishes]);
  const subtotalDrinks = useMemo(() => drinks.reduce((s, d) => s + (d.price ?? 0), 0), [drinks]);
  const subtotalExtras = useMemo(() => extras.reduce((s, e) => s + ((e.price ?? 0) * e.quantity), 0), [extras]);
  const total = subtotalDishes + subtotalDrinks + subtotalExtras;

  return (
    <div className="rounded-xl border border-[color:var(--color-beige)] bg-white p-3">
      <div className="text-sm font-semibold mb-2">Resumen seleccionado</div>

      <Section title="Platos" subtitle={subtotalDishes ? nf.format(subtotalDishes) : undefined}>
        {dishes.length ? (
          <ul className="space-y-1">
            {dishes.map((d) => (
              <li key={d.id} className="flex items-center justify-between gap-2">
                <div className="truncate">
                  {d.name} {typeof d.price === "number" ? <span className="text-xs text-gray-500">({nf.format(d.price)})</span> : null}
                </div>
                <button
                  className="text-xs px-2 py-0.5 rounded-md border border-[color:var(--color-alert)] text-[color:var(--color-alert)] hover:bg-red-50"
                  onClick={() => onRemoveDish(d.id)}
                >
                  Quitar
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <Empty />
        )}
      </Section>

      <Section title="Bodega" subtitle={subtotalDrinks ? nf.format(subtotalDrinks) : undefined}>
        {drinks.length ? (
          <ul className="space-y-1">
            {drinks.map((d) => (
              <li key={d.id} className="flex items-center justify-between gap-2">
                <div className="truncate">
                  {d.name} {typeof d.price === "number" ? <span className="text-xs text-gray-500">({nf.format(d.price)})</span> : null}
                </div>
                <button
                  className="text-xs px-2 py-0.5 rounded-md border border-[color:var(--color-alert)] text-[color:var(--color-alert)] hover:bg-red-50"
                  onClick={() => onRemoveDrink(d.id)}
                >
                  Quitar
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <Empty />
        )}
      </Section>

      <Section title="Extras" subtitle={subtotalExtras ? nf.format(subtotalExtras) : undefined}>
        {extras.length ? (
          <ul className="space-y-1">
            {extras.map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-2">
                <div className="truncate">
                  {e.name} <span className="text-xs text-gray-500">x{e.quantity}</span>{" "}
                  {typeof e.price === "number" ? <span className="text-xs text-gray-500">({nf.format((e.price ?? 0) * e.quantity)})</span> : null}
                </div>
                <div className="flex items-center gap-1">
                  <button
                    className="text-xs px-2 py-0.5 rounded-md border border-[color:var(--color-secondary)] text-[color:var(--color-secondary)]"
                    onClick={() => onDecExtra(e.id)}
                  >
                    −
                  </button>
                  <button
                    className="text-xs px-2 py-0.5 rounded-md bg-[color:var(--color-secondary)] text-white"
                    onClick={() => onIncExtra(e.id)}
                  >
                    +
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <Empty />
        )}
      </Section>

      <div className="mt-3 p-3 rounded-lg bg-[color:var(--color-alt-bg)] flex items-center justify-between">
        <div className="text-sm font-medium">Total</div>
        <div className="text-base font-semibold">{nf.format(total)}</div>
      </div>
    </div>
  );
}

function Section({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="mb-3">
      <div className="mb-1 flex items-center justify-between">
        <div className="text-xs font-semibold uppercase tracking-wide text-[color:var(--color-secondary)]">{title}</div>
        {subtitle && <div className="text-xs text-gray-600">{subtitle}</div>}
      </div>
      {children}
    </div>
  );
}

function Empty() {
  return <div className="text-xs text-gray-500">Sin elementos.</div>;
}
