import React, { useMemo, useState, useEffect } from "react";
import type { EventStatus } from "@/domain/events/types";
import EventStatusControl from "@/features/events/components/EventStatusControl";
import { makeEventsUseCases } from "@/application/events/usecases";
import { EventsHttpGateway } from "@/infrastructure/http/events.gateway";
import CalendarField from "@/features/events/components/CalendarField";

type PersonLite = { id: number; name: string };

type Props = {
  id?: number;                
  title: string | null;
  status: EventStatus;
  date?: string | null;
  users?: PersonLite[];       
  onStatusChanged?: (next: EventStatus) => void;
  onReload?: () => void;      
};

const statusPillCls: Record<EventStatus, string> = {
  confirmed: "bg-green-100 text-green-800 border border-green-200",
  reserved: "bg-yellow-100 text-yellow-800 border border-yellow-200",
  cancelled: "bg-red-100 text-red-800 border border-red-200",
};

const statusLabel: Record<EventStatus, string> = {
  confirmed: "Confirmado",
  reserved: "Reservado",
  cancelled: "Cancelado",
};

export default function EventHeader({
  id,
  title,
  status,
  date,
  users,
  onStatusChanged,
  onReload,
}: Props) {
  const [local, setLocal] = useState<EventStatus>(status);
  useEffect(() => setLocal(status), [status]);

  const headerTitle = useMemo(() => (title ?? "Evento"), [title]);

  // --- Edición de fecha (sustituye tu bloque actual) ---
const [open, setOpen] = useState(false);
const [saving, setSaving] = useState(false);
const [editDate, setEditDate] = useState<string>(date ?? "");

// Normaliza a YYYY-MM-DD (fecha “solo día”)
function toISODateOnly(input: string | Date | null | undefined): string {
  if (!input) return "";
  if (typeof input === "string") {
    // Si ya viene en YYYY-MM-DD lo devolvemos tal cual
    if (/^\d{4}-\d{2}-\d{2}$/.test(input)) return input;
    // Si viene en otro formato que el Date soporte:
    const d = new Date(input);
    if (!isNaN(d.getTime())) {
      return d.toISOString().slice(0, 10);
    }
    return "";
  }
  // Date
  const d = input as Date;
  if (isNaN(d.getTime())) return "";
  return d.toISOString().slice(0, 10);
}

useEffect(() => setEditDate(date ?? ""), [date]);

function openDateModal() {
  setEditDate(date ?? "");
  setOpen(true);
}

async function save() {
  if (!id) return;
  const iso = toISODateOnly(editDate);
  if (!iso) {
    // aquí puedes mostrar tu notificación/toast si usas uno
    return;
  }
  setSaving(true);
  try {
    await eventsUC.updateDate(id, iso);
    setOpen(false);
    onReload?.();
  } finally {
    setSaving(false);
  }
}


  const shownUsers = users  ?? [];

  return (
    <div className="bg-[var(--color-bg-main)] border border-[var(--color-beige)] rounded-xl p-4 mb-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold text-[var(--color-text-main)] truncate">
          {headerTitle}
        </h1>

        {typeof id === "number" ? (
          <EventStatusControl
            eventId={id}
            status={local}
            onChanged={(next) => {
              setLocal(next);
              onStatusChanged?.(next);
            }}
          />
        ) : (
          <span className={`px-2.5 py-0.5 rounded-md text-sm ${statusPillCls[local]}`}>
            {statusLabel[local]}
          </span>
        )}
      </div>

      <div className="mt-2 text-sm text-gray-600 flex flex-wrap items-center gap-3">
        {date && (
          <button
            type="button"
            onClick={openDateModal}
            className="inline-flex items-center gap-1 hover:underline"
            title="Cambiar fecha"
          >
            <span aria-hidden>📅</span>
            <span>{new Date(date).toLocaleDateString()}</span>
          </button>
        )}
        <span>👥 {shownUsers.length ? shownUsers.map((u) => u.name).join(", ") : "Sin usuarios"}</span>
      </div>

      {open && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-lg rounded-xl bg-white p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Cambiar fecha</h3>
              <button onClick={() => setOpen(false)}>✕</button>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-medium">Fecha del evento</label>
              <CalendarField
                value={editDate}
                onChange={(iso) => setEditDate(iso)}
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                className="px-3 py-1.5 rounded-lg border"
                type="button"
                onClick={() => { setEditDate(date ?? ""); setOpen(false); }}
              >
                Cancelar
              </button>
              <button
                className="px-3 py-1.5 rounded-lg bg-[var(--color-primary)] text-white disabled:opacity-50"
                type="button"
                disabled={saving || !editDate || editDate === (date ?? "")}
                onClick={save}
              >
                {saving ? "Guardando…" : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
