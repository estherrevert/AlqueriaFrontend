import React from "react";

export default function InventoryTab() {
  return (
    <div className="p-4 rounded-xl border border-[color:var(--color-beige)] bg-white text-sm text-gray-600">
      El inventario irá en esta pestaña (separado de Menú). Próximamente.
    </div>
  );
}
